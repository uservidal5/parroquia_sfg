@extends('template.base_simple')
@section('page_title')
    Home | Parroquia San Francisco de Guallabamba
@endsection

@section('body')
    @include('public.fragmentos.navbar')
    <div class="container">

    </div>
@endsection
