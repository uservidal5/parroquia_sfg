<div class="row">
    <div class="col-12 col-md-6">
        <div class="card mb-4 rounded-lg">
            <h2 class="card-header py-2"><span class="text-muted">Tus</span> Cursos</h2>
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <?php $__currentLoopData = $matriculado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row py-2 border-bottom">
                                <div class="col-6 mb-2">
                                    <span class="circle rounded-circle text-white bg-primary">
                                        <?php echo e($matricula->nivel_cur); ?>

                                    </span>
                                </div>
                                <div class="col-6 text-end mb-2">
                                    <div class="dropdown">
                                        <button class="btn btn-sm" type="button" data-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="fas fa-info-circle"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            
                                            <a href="<?php echo e(route('matricula.generarPDF', ['matricula' => $matricula])); ?>"
                                                class="dropdown-item" target="_blank">
                                                <i class="fas fa-file-pdf mr-2"></i>
                                                Descargar PDF
                                            </a>
                                            <button type="button" data-toggle="modal"
                                                data-matricula="<?php echo e($matricula->matricula_id); ?>"
                                                data-estado="<?php echo e($matricula->estado_mat); ?>"
                                                data-pago="<?php echo e($matricula->pago_mat); ?>" data-target="#modalMatricula"
                                                class="dropdown-item">
                                                <i class="fas fa-pen mr-2"></i>
                                                Editar
                                            </button>
                                            <button type="button"
                                                onclick="deleteMatricula('<?php echo e($matricula->matricula_id); ?>')"
                                                class="dropdown-item text-danger">
                                                <i class="fas fa-trash mr-2"></i>
                                                Remover
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 mb-2">
                                    <article>
                                        <span class="fw-bold mr-2">
                                            <?php echo e($matricula->nombre_cur); ?>

                                        </span>
                                        <br>
                                        <small class="text-muted mb-0"><?php echo e($matricula->responsable_cur); ?></small>
                                    </article>
                                    <span
                                        class="badge px-2 py-1 badge-opacity-<?php echo e($matricula->estado_mat == 'En curso' ? 'warning' : ($matricula->estado_mat == 'Aprobado' ? 'success' : 'danger')); ?>">
                                        <?php echo e($matricula->estado_mat); ?>

                                    </span>
                                    <span
                                        class="badge px-2 py-1 badge-opacity-<?php echo e($matricula->pago_mat ? 'success' : 'danger'); ?>">
                                        <?php echo e($matricula->pago_mat ? 'Pagado' : 'Sin pago'); ?>

                                    </span>
                                </div>
                                <div class="col-12 mb-2">

                                </div>
                                
                                <div class="col-12 text-muted text-small text-end">
                                    <b>Periodo:</b> <?php echo e($matricula->fecha_inicio_cur); ?>

                                </div>
                                <form action="<?php echo e(route('matriculas.destroy', ['matricula' => $matricula])); ?>"
                                    id="form-delete-matricula-<?php echo e($matricula->matricula_id); ?>" method="POST"
                                    class="d-inline-block mb-2">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6">
        <div class="card mb-4 rounded-lg">
            <h2 class="card-header py-2"><span class="text-muted">En</span> Inscripción</h2>
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        
                        <?php $__currentLoopData = $inscribibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row py-2 border-bottom">
                                <div class="col-12 mb-2">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="circle rounded-circle text-white bg-primary">
                                            <?php echo e($curso->nivel_cur); ?>

                                        </span>
                                        <button type="button" onclick="newMatricula('<?php echo e($curso->id); ?>')"
                                            class="btn btn-outline-info btn-sm">
                                            Inscribir
                                        </button>
                                    </div>
                                </div>
                                <div class="col-12 mb-2">
                                    <article>
                                        <span class="fw-bold mr-2">
                                            <?php echo e($curso->nombre_cur); ?>

                                        </span>
                                        <br>
                                        <small class="text-muted mb-0"><?php echo e($curso->responsable_cur); ?></small>
                                    </article>
                                </div>
                                <div class="col-12">
                                    <div class="text-muted text-small text-end">
                                        <b>Periodo:</b> <?php echo e($curso->fecha_inicio_cur); ?>

                                    </div>
                                </div>
                            </div>
                            
                            <form action="<?php echo e(route('matriculas.store')); ?>" id="form-new-matricula-<?php echo e($curso->id); ?>"
                                method="POST" class="d-inline-block mb-2">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="perfil_id" value="<?php echo e($perfil_id); ?>">
                                <input type="hidden" name="curso_id" value="<?php echo e($curso->id); ?>">
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\fichapsfg\resources\views/dashboard/estudiantes/framentos/seccion_matriculas.blade.php ENDPATH**/ ?>