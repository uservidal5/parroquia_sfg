

<?php $__env->startSection('page_title'); ?>
    Login | Parroquia San Francisco de Guallabamba
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
                    <div class="card" style="width: 40rem;">
                        <div class="card-body p-5">
                            <div class="row">
                                <div class="col-12 mb-4">
                                    <a href="<?php echo e(route('home')); ?>" class="btn btn-link text-muted">
                                        <i class="fas fa-angle-left mr-2"></i>
                                        Regresar
                                    </a>
                                </div>
                                <div class="col-12 mb-4">
                                    <h4 class="text-muted">Parroquia <span class="text-info">San Francisco de
                                            Guayllabamba</span></h4>
                                </div>
                                <div class="col-12">
                                    <span class="fw-semi-bold text-muted">
                                        Hola! Vamos a empezar
                                    </span>
                                </div>
                                <div class="col-12 mb-4">
                                    <span class="fw-light text-info">
                                        Inicia sesión para continuar.
                                    </span>
                                </div>
                            </div>
                            <form action="<?php echo e(route('login')); ?>" method="POST" class="form-row">
                                <?php echo csrf_field(); ?>
                                <div class="col-12 mb-4">
                                    <input type="email" name="email"
                                        class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Correo" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                        autofocus>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 mb-4">
                                    <input type="password"
                                        class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Contraseña" name="password" required autocomplete="current-password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 mb-4 px-2">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                            <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <label class="form-check-label text-muted" for="remember">
                                            Recuerdame
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12 mb-4 text-right">
                                    <?php if(Route::has('password.request')): ?>
                                        <a class="btn btn-link text-info" href="<?php echo e(route('password.request')); ?>">
                                            ¿Olvidó su contraseña?
                                        </a>
                                    <?php endif; ?>

                                    <button type="submit" class="btn btn-dark">
                                        Ingresar
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base_simple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fichapsfg\resources\views/auth/login.blade.php ENDPATH**/ ?>