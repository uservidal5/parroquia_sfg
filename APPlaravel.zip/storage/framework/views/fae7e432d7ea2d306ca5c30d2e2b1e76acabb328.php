
<?php $__env->startSection('page_title'); ?>
    Home | Parroquia San Francisco de Guallabamba
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('public.fragmentos.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base_simple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fichapsfg\resources\views/public/index.blade.php ENDPATH**/ ?>