<script>
    <?php if(session('status') == 'ok'): ?>
        Swal.fire({
            title: 'Listo!',
            text: '<?php echo e(session('message')); ?>',
            icon: 'success',
            showConfirmButton: false,
            timer: 2000
        });
    <?php endif; ?>

    <?php if($errors->any()): ?>
        lanzar_toast("error", "Datos incorrectos!");
    <?php endif; ?>
</script>
<?php /**PATH C:\xampp\htdocs\fichapsfg\resources\views/dashboard/fragemtos/form-status.blade.php ENDPATH**/ ?>