<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item <?php echo e(request()->routeIs('dashboard')); ?>">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <i class="menu-icon fas fa-home"></i>
                <span class="menu-title">
                    Inicio
                </span>
            </a>
        </li>
        
        <li class="nav-item nav-category">ADMINISTRACIÓN</li>
        
        
        
        <li
            class="nav-item <?php echo e(request()->routeIs('estudiantes.index') || request()->is('estudiantes/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('estudiantes.index')); ?>">
                <i class="menu-icon fas fa-user"></i>
                <span class="menu-title">Estudiantes</span>
            </a>
        </li>
        <li
            class="nav-item <?php echo e(request()->routeIs('cursos.index') || request()->is('cursos/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('cursos.index')); ?>">
                <i class="menu-icon fas fa-book"></i>
                <span class="menu-title">Cursos</span>
            </a>
        </li>

    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\fichapsfg\resources\views/template/_dashboard/menu.blade.php ENDPATH**/ ?>