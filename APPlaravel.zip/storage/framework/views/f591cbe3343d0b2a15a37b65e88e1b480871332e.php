<?php echo csrf_field(); ?>
<div class="col-12 mb-4">
    <div class="d-flex justify-content-around align-items-center">
        <div>
            <h3>INFORMACIÓN <?php echo e($parental->tipo_parental_inf == 'PADRE' ? 'DEL PADRE' : 'DE LA MADRE'); ?> </h3>
        </div>
        <div>
            <label class="switch">
                <input type="checkbox" <?php echo e(old('estado_inf', $parental->estado_inf) ? 'checked' : ''); ?> name="estado_inf"
                    id="estado_inf_<?php echo e($type); ?>" value="1">
                <span class="slider round"></span>
            </label>
        </div>
    </div>
    <hr>
</div>
<div class="form-<?php echo e($type); ?> col-12 col-md-6 mb-4" style="display: none;">
    <label for=""><b>APELLIDOS</b></label>
    <input type="text" class="form-control <?php $__errorArgs = ['apellido_inf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="apellido_inf"
        value="<?php echo e(old('apellido_inf', $parental->apellido_inf)); ?>">
    <?php $__errorArgs = ['apellido_inf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-<?php echo e($type); ?> col-12 col-md-6 mb-4" style="display: none;">
    <label for=""><b>NOMBRES</b></label>
    <input type="text" class="form-control <?php $__errorArgs = ['nombre_inf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre_inf"
        value="<?php echo e(old('nombre_inf', $parental->nombre_inf)); ?>">
    <?php $__errorArgs = ['nombre_inf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-<?php echo e($type); ?> col-12 col-md-6 mb-4" style="display: none;">
    <label for=""><b>NÚMERO CELULAR</b></label>
    <input type="text" class="form-control <?php $__errorArgs = ['celular_inf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="celular_inf"
        value="<?php echo e(old('celular_inf', $parental->celular_inf)); ?>">
    <?php $__errorArgs = ['celular_inf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-<?php echo e($type); ?> col-12 col-md-6 mb-4" style="display: none;">
    <label for=""><b>BAUTIZO</b></label>
    <div class="d-flex justify-content-around align-items-center">
        <label>
            SI
            <input <?php echo e($parental->bautizo_inf == 1 ? 'checked' : ''); ?> type="radio" name="bautizo_inf" id=""
                value="1">
        </label>
        <label>
            NO
            <input <?php echo e($parental->bautizo_inf == 0 ? 'checked' : ''); ?> type="radio" name="bautizo_inf" id=""
                value="0">
        </label>
    </div>
</div>
<div class="form-<?php echo e($type); ?> col-12 col-md-6 mb-4" style="display: none;">
    <label for=""><b>COMUNIÓN</b></label>
    <div class="d-flex justify-content-around align-items-center">
        <label>
            SI
            <input <?php echo e($parental->comunion_inf == 1 ? 'checked' : ''); ?> type="radio" name="comunion_inf"
                id="" value="1">
        </label>
        <label>
            NO
            <input <?php echo e($parental->comunion_inf == 0 ? 'checked' : ''); ?> type="radio" name="comunion_inf"
                id="" value="0">
        </label>
    </div>
</div>
<div class="form-<?php echo e($type); ?> col-12 col-md-6 mb-4" style="display: none;">
    <label for=""><b>CONFIRMACIÓN</b></label>
    <div class="d-flex justify-content-around align-items-center">
        <label>
            SI
            <input <?php echo e($parental->confirmacion_inf == 1 ? 'checked' : ''); ?> type="radio" name="confirmacion_inf"
                id="" value="1">
        </label>
        <label>
            NO
            <input <?php echo e($parental->confirmacion_inf == 0 ? 'checked' : ''); ?> type="radio" name="confirmacion_inf"
                id="" value="0">
        </label>
    </div>
</div>
<div class="form-<?php echo e($type); ?> col-12 col-md-6 mb-4" style="display: none;">
    <label for=""><b>MATRIMONIO ECLESIÁSTICO</b></label>
    <div class="d-flex justify-content-around align-items-center">
        <label>
            SI
            <input <?php echo e($parental->matrimonio_inf == 1 ? 'checked' : ''); ?> type="radio" name="matrimonio_inf"
                id="si_matrimonio_inf_<?php echo e($type); ?>" value="1">
        </label>
        <label>
            NO
            <input <?php echo e($parental->matrimonio_inf == 0 ? 'checked' : ''); ?> type="radio" name="matrimonio_inf"
                id="no_matrimonio_inf_<?php echo e($type); ?>" value="0">
        </label>
    </div>
</div>
<div class="form-<?php echo e($type); ?> col-12 col-md-6 mb-4" style="display: none;">
    <div class="select-<?php echo e($type); ?>-estado_civil_inf">
        <label for=""><b>ESTADO CIVIL</b></label>
        <select name="estado_civil_inf" id="" class="form-control">
            <option value=""></option>
            <option
                <?php echo e($parental->estado_civil_inf == 'SOLTERO' || $parental->estado_civil_inf == 'SOLTERA' ? 'selected' : ''); ?>

                value="<?php echo e($parental->tipo_parental_inf == 'PADRE' ? 'SOLTERO' : 'SOLTERA'); ?>">
                <?php echo e($parental->tipo_parental_inf == 'PADRE' ? 'SOLTERO' : 'SOLTERA'); ?>

            </option>
            <option <?php echo e($parental->estado_civil_inf == 'UNION_LIBRE' ? 'selected' : ''); ?> value="UNION_LIBRE">
                UNION LIBRE
            </option>
            <option
                <?php echo e($parental->estado_civil_inf == 'DIVORCIADO' || $parental->estado_civil_inf == 'DIVORCIADA' ? 'selected' : ''); ?>

                value="<?php echo e($parental->tipo_parental_inf == 'PADRE' ? 'DIVORCIADO' : 'DIVORCIADA'); ?>">
                <?php echo e($parental->tipo_parental_inf == 'PADRE' ? 'DIVORCIADO' : 'DIVORCIADA'); ?>

            </option>
            <option
                <?php echo e($parental->estado_civil_inf == 'VIUDO' || $parental->estado_civil_inf == 'VIUDA' ? 'selected' : ''); ?>

                value="<?php echo e($parental->tipo_parental_inf == 'PADRE' ? 'VIUDO' : 'VIUDA'); ?>">
                <?php echo e($parental->tipo_parental_inf == 'PADRE' ? 'VIUDO' : 'VIUDA'); ?>

            </option>
        </select>
    </div>
</div>
<?php $__env->startPush('js_footer'); ?>
    <script>
        $("#si_matrimonio_inf_<?php echo e($type); ?>").change(() => {
            toggle_matrimonio("<?php echo e($type); ?>");
        });
        $("#no_matrimonio_inf_<?php echo e($type); ?>").change(() => {
            toggle_matrimonio("<?php echo e($type); ?>");
        });

        $("#estado_inf_<?php echo e($type); ?>").change(() => {
            form_parental("<?php echo e($type); ?>");
        });
        //
        $(() => {
            form_parental("<?php echo e($type); ?>");
        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\fichapsfg\resources\views/dashboard/estudiantes/framentos/form-parental.blade.php ENDPATH**/ ?>