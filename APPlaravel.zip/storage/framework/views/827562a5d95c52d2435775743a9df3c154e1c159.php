


<?php $__env->startSection('page_title'); ?>
    Mi perfil | Inicio
<?php $__env->stopSection(); ?>
<?php $__env->startSection('name_section'); ?>
    <ul class="navbar-nav">
        <li class="nav-item font-weight-semibold d-none d-lg-block ms-0">
            <h1 class="welcome-text">Gestiona tu <span class="text-black fw-bold">Perfil</span></h1>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="card mb-4">
        <div class="card-body card-text">
            <div class="row">
                <div class="col-12 col-md-3 border-right">
                    <h3 class="text-muted">Datos <span class="text-dark">Informativos</span></h3>
                </div>
                <div class="col-12 col-md-9">
                    <form action="<?php echo e(route('user.actualizar_datos_personales')); ?>" class="form-row" method="POST"
                        id="form-datos-personales">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="col-12 mb-4">
                            <label for=""><b><?php echo e(__('Full Name')); ?></b></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                value="<?php echo e(old('name') ?: Auth::user()->name); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 mb-4">
                            <label for=""><b><?php echo e(__('Email Address')); ?></b></label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                value="<?php echo e(old('email') ?: Auth::user()->email); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 text-end">
                            <button type="submit" class="btn-submit btn btn-dark">Actualizar</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <div class="card-text">
                <div class="row">
                    <div class="col-12 col-md-3 border-right">
                        <h3 class="text-muted">Cambiar <span class="text-dark">Contraseña</span></h3>
                    </div>
                    <div class="col-12 col-md-9">
                        <form action="<?php echo e(route('user.cambiar_clave_acceso')); ?>" method="POST" class="form-row">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?> <div class="col-12 mb-4">
                                <label for=""><b><?php echo e(__('Old password')); ?></b></label>
                                <input type="password" class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="old_password">
                                <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 mb-4">
                                <label for=""><b><?php echo e(__('New password')); ?></b></label>
                                <input type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="new_password">
                                <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 mb-4">
                                <label for=""><b><?php echo e(__('Repet password')); ?></b></label>
                                <input type="password" class="form-control <?php $__errorArgs = ['re_new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="re_new_password">
                                <?php $__errorArgs = ['re_new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 text-end">
                                <button type="submit" class="btn-submit btn btn-dark">
                                    Cambiar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card mb-4 bg-inverse-danger">
        <div class="card-body">
            <div class="card-text">
                <div class="row">
                    <div class="col-12 col-md-3 border-right">
                        <h3 class="text-dark">Elimina tu <span class="text-danger">Perfil</span></h3>
                    </div>
                    <div class="col-12 col-md-9">
                        <form action="" class="form-row">
                            <div class="col-12  mb-4">
                                <label for=""><b><?php echo e(__('Password')); ?> de confirmación</b></label>
                                <input type="password" class="form-control" name="name" value="">
                            </div>
                            <div class="col-12 ">
                                <label class="">
                                    <input checked type="radio" name="tipo-baja" class="mr-2">
                                    Desactivar Perfil
                                </label>
                                <br>
                                <label class="">
                                    <input type="radio" name="tipo-baja" class="mr-2">
                                    <b class="text-danger">Eliminar Perfil</b>
                                </label>
                            </div>
                            <div class="col-12 text-end">
                                <button type="button" class="btn btn-dark">Confirmar</button>
                            </div>
                        </form>




                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $("form").submit((event) => {
            // event.preventDefault();
            const loading_text = `<i class="fas fa-spin fa-spinner mr-2"></i>Espere`;
            const form = event.target;
            $(form).find(".btn-submit").prop("disabled", true);
            $(form).find(".btn-submit").html(loading_text);
            // console.log("clik");
        });
        <?php if(session('status')): ?>
            lanzar_toast("success", '<?php echo e(session('message')); ?>');
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fichapsfg\resources\views/dashboard/user/profile.blade.php ENDPATH**/ ?>