<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Parroquia <b>SFG</b></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="#">Matriculas</a>
            </li>
            <li
                class="nav-item <?php echo e(request()->routeIs('acceso_estudiantes') ||
                request()->is('acceso_estudiantes/*') ||
                request()->routeIs('inicio_estudiante.index') ||
                request()->is('panel_estudiante/*')
                    ? 'active'
                    : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('acceso_estudiantes', ['type' => 'login'])); ?>">Acceso Estudiantes</a>
            </li>
        </ul>
        <div>
            <!-- Authentication Links -->
            <?php if(!session('idPerfilLogin')): ?>
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-info">
                            Iniciar Sesión
                        </a>
                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <a class="btn btn-link text-white" href="<?php echo e(route('register')); ?>">Registrate</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a class="btn btn-link text-white" href="<?php echo e(route('dashboard')); ?>">Ir al dashboard</a>
                    
                <?php endif; ?>
            <?php endif; ?>

        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\fichapsfg\resources\views/public/fragmentos/navbar.blade.php ENDPATH**/ ?>